# Lists. Like ArrayList/vector in Java/C++
alist = [1, 2, 3, 4]
alist.append(5)
print(alist[3])

# Tuple. Immutable. Like tuples in C++
atuple = (1, 2, 3)

# Set. Like HashSet / unordered set in Java/C++
aset = { 1, 2, 3, 2 }
aset.add(1)
aset.remove(2)
print("Is 5 in the set:", 5 in aset)
print("The set contains:", aset)

# Dictionary. Like HashMap / unordered map in Java/C++
adict = { 1: "Good", 2: "Average", 3: "Bad" }
adict[4] = "Horrible"
print("Level 2 is", adict[2])
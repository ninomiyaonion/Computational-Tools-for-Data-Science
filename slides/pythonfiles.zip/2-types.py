def printInfo(b):
    print("The value is", b, "and the type is", type(b))

printInfo(15)
printInfo(99999999999999999999999999)
printInfo(5.5)
printInfo("hello")
printInfo(True or False)

a = 5
a = "str"
print(a)


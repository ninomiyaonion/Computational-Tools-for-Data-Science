print("### For loop 1: ")

for i in range(0, 5):
    print(i ** 2)

print("### For loop 2: ")

for val in ["Ice", "Price", "Wise"]:
    print(val)

print("### While loop: ")

a = 1
while a < 20:
    print(a)
    a = a * 2
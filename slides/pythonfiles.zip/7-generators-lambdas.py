squares = [x ** 2 for x in range(0, 10)]
print(squares)

evenSquares = list(filter(lambda x: x % 2 == 0, squares))
print(evenSquares)

squaredSquares = list(map(lambda x: x ** 2, squares))
print(squaredSquares)
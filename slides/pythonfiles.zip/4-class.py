class Box:
    def __init__(self, width, depth, height):
        self._width = width
        self._depth = depth
        self._height = height

    def volume(self):
        return self._width * self._depth * self._height
    
    def grow(self, factor):
        self._width = self._width * factor
        self._depth = self._depth * factor
        self._height = self._height * factor

b1 = Box(3, 2, 1)
print(b1.volume())
b1.grow(2)
print(b1.volume())
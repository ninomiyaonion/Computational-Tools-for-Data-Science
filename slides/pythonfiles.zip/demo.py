import urllib.request

url = "http://roysoft.dk/02807.txt"

response = urllib.request.urlopen(url)

data = response.read().decode("utf-8")
lines = data.split("\n")

count = {}

for line in lines:
    if line in count:
        count[line] += 1
    else:
        count[line] = 1

for line in sorted(count, key = lambda x: -count[x]):
    print(line, "has", count[line], "students")